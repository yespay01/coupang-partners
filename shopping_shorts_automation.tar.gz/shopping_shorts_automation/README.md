# 🎬 쇼핑 쇼츠 자동화 도우미

쿠팡 파트너스 제휴 마케팅을 위한 쇼츠 콘텐츠 제작 반자동화 시스템

## 📋 주요 기능

- ✅ 상품명 입력 → 릴스 대본 자동 생성
- ✅ 썸네일 문구 자동 생성
- ✅ 설명란 (CTA 포함) 자동 생성
- ✅ Douyin 검색용 중국어 키워드 자동 변환
- ✅ 작업 폴더 자동 생성 및 정리
- ✅ 체크리스트 자동 생성 (CSV)

## 🚀 빠른 시작

### 1. 필수 패키지 설치
```bash
pip install -r requirements.txt
```

### 2. OpenAI API 키 설정
`.env` 파일을 생성하고 API 키를 입력하세요:
```
OPENAI_API_KEY=your_api_key_here
```

### 3. 프로그램 실행
```bash
streamlit run app.py
```

## 📁 프로젝트 구조

```
shopping_shorts_automation/
├── app.py                    # Streamlit 메인 앱
├── modules/
│   ├── script_generator.py  # 대본 생성 모듈
│   ├── keyword_translator.py # 키워드 번역 모듈
│   └── file_manager.py       # 파일/폴더 관리 모듈
├── prompts/
│   └── script_prompt.txt     # ChatGPT 프롬프트 템플릿
├── project_output/           # 생성된 프로젝트 폴더
│   └── [상품명]/
│       ├── script.txt
│       ├── checklist.csv
│       └── metadata.json
├── requirements.txt
├── .env
└── README.md
```

## 💡 사용 방법

1. 웹 브라우저에서 Streamlit 앱 열기
2. 상품명 또는 쿠팡 URL 입력
3. '대본 생성' 버튼 클릭
4. 생성된 폴더에서 파일 확인
5. 체크리스트를 따라 수동 작업 진행

## 🔧 환경 설정

- Python 3.8 이상
- OpenAI API 키 (GPT-4 권장)

## 📊 출력 파일

각 상품별로 다음 파일들이 자동 생성됩니다:

- `script.txt` - 30-45초 분량 대본
- `thumbnail.txt` - 6-8자 썸네일 문구
- `description.txt` - 설명란 + CTA
- `douyin_keywords.txt` - 중국어 검색 키워드
- `checklist.csv` - 작업 단계 체크리스트
- `metadata.json` - 생성 일시 및 설정 정보

## 🎯 다음 단계 (수동 작업)

1. Douyin에서 키워드로 영상 검색
2. 도인로드로 영상 다운로드
3. Typecast에서 음성/자막 생성
4. CapCut에서 영상 편집
5. Send Anywhere로 모바일 전송
6. 업로드 및 수익화

## 📈 향후 확장 계획

- [ ] Douyin 자동 다운로드
- [ ] AI 음성/자막 자동 생성
- [ ] FFmpeg 기반 기본 영상 편집
- [ ] 수익 트래킹 대시보드

## ⚠️ 주의사항

- OpenAI API 사용료 발생 (요청당 약 $0.01-0.05)
- 쿠팡 파트너스 이용약관 준수 필수
- Douyin 영상 사용 시 저작권 확인 권장
