# 📋 개발 계획 및 로드맵

## 🎯 프로젝트 목표

**최종 목표**: 쿠팡 파트너스 제휴마케팅을 위한 쇼츠 콘텐츠 제작 프로세스를 50% 이상 자동화

**Phase 1 목표**: 상품명 입력 → 대본/키워드/체크리스트 자동 생성 (작업 시간 30% 단축)

---

## 🗓️ 전체 로드맵

### Phase 1: 반자동 도우미 (2주, 기본 MVP)
**목표**: 대본 생성 및 파일 관리 자동화

**구현 기능:**
- ✅ 상품명 입력 UI (Streamlit)
- ✅ ChatGPT API로 릴스 대본 자동 생성
- ✅ 썸네일 문구 자동 생성 (6-8자)
- ✅ 설명란 + CTA 자동 생성
- ✅ 한국어 → 중국어 키워드 번역
- ✅ 프로젝트 폴더 자동 생성
- ✅ 체크리스트 CSV 생성
- ✅ 메타데이터 JSON 저장

**수동 작업 (이 단계에서는 유지):**
- Douyin 영상 검색 및 다운로드
- Typecast 음성/자막 생성
- CapCut 영상 편집
- 모바일 전송 및 업로드

**예상 작업 시간:**
- 기존: 60분/콘텐츠
- Phase 1 후: 42분/콘텐츠 (30% 단축)

---

### Phase 2: 콘텐츠 제작 자동화 (2주)
**목표**: 음성/자막 생성 및 기본 영상 편집 자동화

**구현 기능:**
- ⬜ Google Cloud TTS API 연동 (음성 합성)
- ⬜ 자막 SRT 파일 자동 생성
- ⬜ FFmpeg + MoviePy로 기본 영상 편집
  - 영상 리사이즈 (9:16)
  - 자막 오버레이
  - 음성 합성
- ⬜ 일괄 처리 기능 (배치 모드)

**수동 작업 (여전히 유지):**
- Douyin 영상 다운로드
- 고급 편집 (CapCut)
- 업로드

**예상 작업 시간:**
- Phase 1: 42분/콘텐츠
- Phase 2 후: 25분/콘텐츠 (58% 단축)

---

### Phase 3: 데이터 수집 자동화 (2주)
**목표**: 상품 리서치 및 영상 소스 수집 자동화

**구현 기능:**
- ⬜ 쿠팡 URL 파싱 (BeautifulSoup)
  - 상품명, 가격, 리뷰 자동 추출
- ⬜ Douyin 영상 자동 다운로드 (Selenium)
- ⬜ 트렌드 상품 추천 시스템
- ⬜ 상품 데이터베이스 구축 (SQLite)

**수동 작업:**
- 고급 편집
- 업로드

**예상 작업 시간:**
- Phase 2: 25분/콘텐츠
- Phase 3 후: 15분/콘텐츠 (75% 단축)

---

### Phase 4: 분석 및 최적화 (선택)
**목표**: 성과 트래킹 및 수익 최적화

**구현 기능:**
- ⬜ YouTube/Instagram API 연동
- ⬜ 조회수, 클릭률 자동 수집
- ⬜ EPC (클릭당 수익) 계산
- ⬜ Streamlit 대시보드
  - 일별/주별/월별 성과
  - 상위 성과 상품 분석
  - 트렌드 그래프
- ⬜ A/B 테스트 지원 (썸네일, 대본)

**예상 작업 시간:**
- Phase 3: 15분/콘텐츠
- Phase 4 후: 10분/콘텐츠 (83% 단축)

---

## 📅 주차별 개발 계획 (Phase 1)

### Week 1: 환경 설정 및 핵심 모듈

#### Day 1-2: 프로젝트 초기화
**할 일:**
- [x] 폴더 구조 생성
- [ ] 가상환경 설정
- [ ] requirements.txt 작성
- [ ] .env.example 작성
- [ ] .gitignore 설정
- [ ] Git 초기화

**산출물:**
```
shopping_shorts_automation/
├── app/
├── modules/
├── prompts/
├── docs/
├── requirements.txt
├── .env.example
└── README.md
```

#### Day 3-4: 대본 생성 모듈
**할 일:**
- [ ] OpenAI API 연동 테스트
- [ ] 프롬프트 템플릿 작성 (`prompts/script_prompt.txt`)
- [ ] `script_generator.py` 구현
  - `generate_script(product_name)` 함수
  - 에러 핸들링
  - 토큰 사용량 로깅
- [ ] 단위 테스트 작성

**테스트 케이스:**
```python
# 입력
product_name = "무선 신발 건조기"

# 기대 출력
{
    "script": "30-45초 대본...",
    "thumbnail": "신발 냄새 제거",
    "description": "링크: [쿠팡 URL]\n#신발건조기...",
    "token_usage": 1234
}
```

#### Day 5: 키워드 번역 모듈
**할 일:**
- [ ] `keyword_translator.py` 구현
  - `translate_to_chinese(product_name)` 함수
  - GPT-4로 자연스러운 번역
  - Douyin 검색에 최적화된 키워드 생성

**테스트 케이스:**
```python
# 입력
product_name = "무선 신발 건조기"

# 기대 출력
{
    "keywords": ["无线鞋子烘干机", "便携式鞋烘干器"],
    "search_query": "无线鞋子烘干机"
}
```

#### Day 6-7: 파일 관리 모듈
**할 일:**
- [ ] `file_manager.py` 구현
  - `create_project_folder(product_name)` 함수
  - 폴더명: `[상품명]_[날짜]` 형식
  - 텍스트 파일 저장 함수들
  - JSON 메타데이터 생성
- [ ] `checklist_creator.py` 구현
  - 체크리스트 템플릿 정의
  - CSV 생성 함수

**출력 폴더 구조:**
```
project_output/
└── 무선_신발_건조기_20251030/
    ├── script.txt
    ├── thumbnail.txt
    ├── description.txt
    ├── douyin_keywords.txt
    ├── checklist.csv
    └── metadata.json
```

---

### Week 2: UI 개발 및 통합 테스트

#### Day 8-10: Streamlit UI 개발
**할 일:**
- [ ] `app/main.py` 구현
  - 메인 페이지 레이아웃
  - 입력 폼 (상품명, 카테고리)
  - "대본 생성" 버튼
  - 진행 상태 표시 (progress bar)
  - 결과 표시 (미리보기)
- [ ] `app/config.py` 구현
  - 설정 관리 (API 키, 경로 등)

**UI 구성:**
```
┌─────────────────────────────────────┐
│  🎬 쇼핑 쇼츠 자동화 도우미         │
├─────────────────────────────────────┤
│                                     │
│  상품명: [___________________]      │
│                                     │
│  카테고리: [가전  ▼]                │
│                                     │
│  [ 🚀 대본 생성 ]                   │
│                                     │
│  ━━━━━━━━━━━━━━━ 50% ━━━━━━━━━━━  │
│  대본 생성 중...                    │
│                                     │
├─────────────────────────────────────┤
│  📄 생성된 대본 미리보기             │
│  ┌───────────────────────────────┐ │
│  │ 장마철 신발 냄새 때문에...    │ │
│  │                               │ │
│  └───────────────────────────────┘ │
│                                     │
│  📁 저장 위치:                      │
│  project_output/무선_신발_건조기_.. │
│                                     │
│  [ 📂 폴더 열기 ] [ 📋 복사 ]      │
└─────────────────────────────────────┘
```

#### Day 11-12: 통합 및 테스트
**할 일:**
- [ ] 모든 모듈 통합
- [ ] 전체 프로세스 테스트
  - 정상 케이스
  - 에러 케이스 (API 오류, 네트워크 끊김)
- [ ] 사용자 시나리오 테스트
- [ ] 버그 수정

**테스트 시나리오:**
1. 상품명 입력 → 대본 생성 성공
2. 특수문자 포함 상품명 → 파일명 정리
3. 매우 긴 상품명 → 파일명 축약
4. API 키 없음 → 에러 메시지
5. 인터넷 끊김 → 재시도 안내

#### Day 13-14: 문서화 및 배포 준비
**할 일:**
- [ ] README.md 작성
  - 설치 방법
  - 사용 방법
  - 스크린샷
- [ ] 사용자 가이드 작성 (`docs/USER_GUIDE.md`)
- [ ] 코드 주석 추가
- [ ] 요구사항 문서 최종 확인
- [ ] 실행 스크립트 작성 (setup.py)

---

## 🏗️ 주요 모듈 상세 설계

### 1. script_generator.py

```python
"""
대본 자동 생성 모듈
OpenAI GPT-4를 사용하여 릴스 대본, 썸네일, 설명란 생성
"""

import openai
from typing import Dict
import logging

class ScriptGenerator:
    def __init__(self, api_key: str, model: str = "gpt-4-turbo-preview"):
        self.api_key = api_key
        self.model = model
        openai.api_key = api_key
        self.logger = logging.getLogger(__name__)
    
    def generate_script(self, product_name: str, category: str = "일반") -> Dict:
        """
        릴스 대본 생성
        
        Args:
            product_name: 상품명
            category: 카테고리 (선택)
        
        Returns:
            {
                "script": "30-45초 대본",
                "thumbnail": "썸네일 문구",
                "description": "설명란 + CTA",
                "token_usage": 사용한 토큰 수
            }
        """
        # 프롬프트 로드
        prompt = self._load_prompt_template(product_name, category)
        
        try:
            # API 호출
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "당신은 쇼핑 쇼츠 전문가입니다."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1500
            )
            
            # 결과 파싱
            result = self._parse_response(response)
            
            self.logger.info(f"대본 생성 완료: {product_name}")
            return result
            
        except openai.error.RateLimitError:
            self.logger.error("API 요청 한도 초과")
            raise
        except Exception as e:
            self.logger.error(f"대본 생성 오류: {e}")
            raise
    
    def _load_prompt_template(self, product_name: str, category: str) -> str:
        """프롬프트 템플릿 로드 및 변수 치환"""
        with open("prompts/script_prompt.txt", "r", encoding="utf-8") as f:
            template = f.read()
        
        return template.format(
            product_name=product_name,
            category=category
        )
    
    def _parse_response(self, response) -> Dict:
        """API 응답 파싱"""
        content = response.choices[0].message.content
        token_usage = response.usage.total_tokens
        
        # TODO: 응답 내용을 구조화된 형태로 파싱
        # 예: ### 대본, ### 썸네일 등의 마커 기반
        
        return {
            "script": "...",
            "thumbnail": "...",
            "description": "...",
            "token_usage": token_usage
        }
```

### 2. file_manager.py

```python
"""
파일 및 폴더 관리 모듈
프로젝트 폴더 생성, 파일 저장, 메타데이터 관리
"""

from pathlib import Path
from datetime import datetime
import json
import logging
from typing import Dict

class FileManager:
    def __init__(self, base_dir: str = "project_output"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(exist_ok=True)
        self.logger = logging.getLogger(__name__)
    
    def create_project_folder(self, product_name: str) -> Path:
        """
        프로젝트 폴더 생성
        
        Args:
            product_name: 상품명
        
        Returns:
            생성된 폴더 경로
        """
        # 파일명에 사용 불가능한 문자 제거
        safe_name = self._sanitize_filename(product_name)
        
        # 날짜 추가
        date_str = datetime.now().strftime("%Y%m%d")
        folder_name = f"{safe_name}_{date_str}"
        
        folder_path = self.base_dir / folder_name
        folder_path.mkdir(exist_ok=True)
        
        self.logger.info(f"폴더 생성: {folder_path}")
        return folder_path
    
    def save_script_files(self, folder_path: Path, data: Dict):
        """
        생성된 데이터를 파일로 저장
        
        Args:
            folder_path: 저장할 폴더 경로
            data: 대본, 썸네일 등의 데이터
        """
        # 대본
        (folder_path / "script.txt").write_text(
            data["script"], 
            encoding="utf-8"
        )
        
        # 썸네일
        (folder_path / "thumbnail.txt").write_text(
            data["thumbnail"], 
            encoding="utf-8"
        )
        
        # 설명란
        (folder_path / "description.txt").write_text(
            data["description"], 
            encoding="utf-8"
        )
        
        # Douyin 키워드
        if "douyin_keywords" in data:
            (folder_path / "douyin_keywords.txt").write_text(
                data["douyin_keywords"], 
                encoding="utf-8"
            )
        
        # 메타데이터
        metadata = {
            "created_at": datetime.now().isoformat(),
            "product_name": data.get("product_name"),
            "token_usage": data.get("token_usage")
        }
        
        (folder_path / "metadata.json").write_text(
            json.dumps(metadata, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
        
        self.logger.info(f"파일 저장 완료: {folder_path}")
    
    def _sanitize_filename(self, filename: str) -> str:
        """파일명에서 사용 불가능한 문자 제거"""
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        
        # 최대 길이 제한 (50자)
        if len(filename) > 50:
            filename = filename[:50]
        
        return filename
```

### 3. checklist_creator.py

```python
"""
체크리스트 생성 모듈
작업 단계 체크리스트를 CSV로 생성
"""

import pandas as pd
from pathlib import Path
import logging

class ChecklistCreator:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # 기본 체크리스트 항목
        self.checklist_items = [
            {"단계": "1️⃣ 제품 선정", "상태": "✅ 완료", "소요시간": "5분", "비고": "자동 완료"},
            {"단계": "2️⃣ 영상 소스 확보", "상태": "⬜ 대기", "소요시간": "10분", "비고": "Douyin 검색"},
            {"단계": "3️⃣ 영상 다운로드", "상태": "⬜ 대기", "소요시간": "5분", "비고": "도인로드 사용"},
            {"단계": "4️⃣ 대본·캡션 생성", "상태": "✅ 완료", "소요시간": "10분", "비고": "자동 완료"},
            {"단계": "5️⃣ AI 음성·자막", "상태": "⬜ 대기", "소요시간": "15분", "비고": "Typecast"},
            {"단계": "6️⃣ 영상 편집", "상태": "⬜ 대기", "소요시간": "20분", "비고": "CapCut"},
            {"단계": "7️⃣ 모바일 전송", "상태": "⬜ 대기", "소요시간": "2분", "비고": "Send Anywhere"},
            {"단계": "8️⃣ 업로드·수익화", "상태": "⬜ 대기", "소요시간": "5분", "비고": "Infok Link 설정"}
        ]
    
    def create_checklist(self, folder_path: Path, product_name: str):
        """
        체크리스트 CSV 생성
        
        Args:
            folder_path: 저장할 폴더 경로
            product_name: 상품명
        """
        df = pd.DataFrame(self.checklist_items)
        
        # CSV 저장 (한글 깨짐 방지)
        csv_path = folder_path / "checklist.csv"
        df.to_csv(csv_path, index=False, encoding="utf-8-sig")
        
        self.logger.info(f"체크리스트 생성: {csv_path}")
        
        return csv_path
```

---

## 🎨 UI/UX 디자인 가이드

### Streamlit 페이지 구성

#### 1. 헤더
```python
st.set_page_config(
    page_title="쇼핑 쇼츠 자동화 도우미",
    page_icon="🎬",
    layout="wide"
)

st.title("🎬 쇼핑 쇼츠 자동화 도우미")
st.markdown("쿠팡 파트너스 제휴마케팅 콘텐츠 제작 자동화")
```

#### 2. 입력 섹션
```python
with st.form("product_form"):
    st.subheader("📝 상품 정보 입력")
    
    product_name = st.text_input(
        "상품명 또는 쿠팡 URL",
        placeholder="예: 무선 신발 건조기"
    )
    
    category = st.selectbox(
        "카테고리 (선택)",
        ["일반", "가전", "패션", "뷰티", "식품", "생활용품"]
    )
    
    submitted = st.form_submit_button("🚀 대본 생성", use_container_width=True)
```

#### 3. 진행 상태
```python
if submitted and product_name:
    with st.spinner("대본 생성 중..."):
        progress_bar = st.progress(0)
        
        # 1. 대본 생성
        progress_bar.progress(25)
        script_data = generator.generate_script(product_name, category)
        
        # 2. 키워드 번역
        progress_bar.progress(50)
        keywords = translator.translate(product_name)
        
        # 3. 폴더 생성
        progress_bar.progress(75)
        folder_path = file_manager.create_project_folder(product_name)
        
        # 4. 파일 저장
        progress_bar.progress(100)
        file_manager.save_all(folder_path, script_data, keywords)
        
        st.success("✅ 생성 완료!")
```

#### 4. 결과 표시
```python
# 탭으로 구분
tab1, tab2, tab3, tab4 = st.tabs(["📄 대본", "🖼️ 썸네일", "📝 설명란", "🔤 키워드"])

with tab1:
    st.text_area("대본 (30-45초)", script_data["script"], height=300)
    st.button("📋 복사", key="copy_script")

with tab2:
    st.text_input("썸네일 문구", script_data["thumbnail"])
    st.caption("6-8자 권장")

with tab3:
    st.text_area("설명란", script_data["description"], height=200)

with tab4:
    st.code(keywords["chinese"], language="text")
    st.caption("Douyin 검색용 키워드")
```

#### 5. 액션 버튼
```python
col1, col2, col3 = st.columns(3)

with col1:
    st.button("📂 폴더 열기", on_click=open_folder)

with col2:
    st.button("📊 대시보드", on_click=show_dashboard)

with col3:
    st.download_button(
        "💾 체크리스트 다운로드",
        data=checklist_csv,
        file_name="checklist.csv"
    )
```

---

## 🧪 테스트 계획

### 단위 테스트 (pytest)

```python
# tests/test_script_generator.py

def test_generate_script_success():
    """정상 케이스: 대본 생성 성공"""
    generator = ScriptGenerator(api_key=TEST_API_KEY)
    result = generator.generate_script("무선 신발 건조기")
    
    assert "script" in result
    assert len(result["script"]) > 100
    assert "thumbnail" in result
    assert len(result["thumbnail"]) <= 10

def test_generate_script_empty_name():
    """에러 케이스: 상품명 없음"""
    generator = ScriptGenerator(api_key=TEST_API_KEY)
    
    with pytest.raises(ValueError):
        generator.generate_script("")

def test_generate_script_api_error():
    """에러 케이스: API 오류"""
    generator = ScriptGenerator(api_key="invalid_key")
    
    with pytest.raises(openai.error.AuthenticationError):
        generator.generate_script("테스트")
```

### 통합 테스트

```python
# tests/test_integration.py

def test_full_workflow():
    """전체 워크플로우 테스트"""
    # 1. 대본 생성
    script_data = generator.generate_script("무선 신발 건조기")
    
    # 2. 키워드 번역
    keywords = translator.translate("무선 신발 건조기")
    
    # 3. 폴더 생성
    folder_path = file_manager.create_project_folder("무선 신발 건조기")
    
    # 4. 파일 저장
    file_manager.save_all(folder_path, script_data, keywords)
    
    # 검증
    assert (folder_path / "script.txt").exists()
    assert (folder_path / "checklist.csv").exists()
    assert (folder_path / "metadata.json").exists()
```

---

## 📊 성과 지표 (KPI)

### Phase 1 목표

| 지표 | 목표 | 측정 방법 |
|------|------|----------|
| 작업 시간 단축 | 30% | 기존 60분 → 42분 |
| API 비용 | ₩10,000/월 이하 | OpenAI 대시보드 |
| 에러율 | 5% 이하 | 로그 분석 |
| 사용자 만족도 | 4.0/5.0 이상 | 피드백 수집 |

### 개발 진행률 추적

```python
# 체크리스트
☐ 환경 설정 (0/5)
  ☐ 폴더 구조 생성
  ☐ 가상환경 설정
  ☐ 패키지 설치
  ☐ .env 설정
  ☐ Git 초기화

☐ 핵심 모듈 (0/3)
  ☐ script_generator.py
  ☐ keyword_translator.py
  ☐ file_manager.py

☐ UI 개발 (0/2)
  ☐ Streamlit 앱
  ☐ 결과 표시

☐ 테스트 (0/3)
  ☐ 단위 테스트
  ☐ 통합 테스트
  ☐ 사용자 시나리오

☐ 문서화 (0/2)
  ☐ README
  ☐ 사용자 가이드
```

---

## 🚨 리스크 관리

### 주요 리스크

| 리스크 | 발생 확률 | 영향도 | 대응 방안 |
|--------|----------|--------|----------|
| API 비용 초과 | 중 | 높음 | 일일 요청 한도 설정 |
| API 서비스 장애 | 낮음 | 높음 | 재시도 로직, 에러 메시지 |
| 쿠팡 정책 변경 | 중 | 중간 | 정기적인 정책 확인 |
| 개발 일정 지연 | 중 | 중간 | 핵심 기능 우선순위화 |

### 대응 전략

**1. API 비용 관리**
```python
# 일일 요청 한도
MAX_DAILY_REQUESTS = 100

# 요청 전 확인
if request_count >= MAX_DAILY_REQUESTS:
    st.error("⚠️ 오늘의 요청 한도를 초과했습니다.")
    st.info(f"내일 다시 시도해주세요. ({request_count}/{MAX_DAILY_REQUESTS})")
    return
```

**2. API 장애 대응**
```python
import time

def api_call_with_retry(func, max_retries=3):
    for i in range(max_retries):
        try:
            return func()
        except openai.error.APIError as e:
            if i == max_retries - 1:
                raise
            time.sleep(2 ** i)  # 지수 백오프
```

---

## 📚 참고 자료

### 공식 문서
- [Streamlit 문서](https://docs.streamlit.io/)
- [OpenAI API 문서](https://platform.openai.com/docs/)
- [Pandas 문서](https://pandas.pydata.org/docs/)

### 유용한 튜토리얼
- Streamlit 빠른 시작: https://docs.streamlit.io/get-started
- OpenAI API 예제: https://platform.openai.com/examples

### 커뮤니티
- Streamlit 포럼: https://discuss.streamlit.io/
- Python 한국 사용자 모임: https://python.kr/

---

## 📝 변경 이력

| 날짜 | 버전 | 변경 내용 |
|------|------|----------|
| 2025-10-30 | v1.0 | 초기 계획 수립 |

---

> 💡 **다음 단계**: 이 계획을 검토하고 승인되면 실제 코드 개발을 시작합니다!
