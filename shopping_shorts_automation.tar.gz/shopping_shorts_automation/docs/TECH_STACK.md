# 🛠️ 유튜브 제휴마케팅 자동화 시스템 기술 스택 (통합판)

## 📌 프로젝트 개요
- **프로젝트명**: 쇼핑 쇼츠 자동화 시스템
- **목표**: 쿠팡 파트너스 제휴마케팅 콘텐츠 제작 완전 자동화
- **아키텍처**: 마이크로서비스 기반 (API + UI + 워커)
- **개발 단계**: Phase 1 (MVP) → Phase 4 (완전 자동화)
- **대상 사용자**: 코딩 초보자 ~ 중급자
- **플랫폼**: 로컬 실행 / 클라우드 배포 가능

---

## 🏗️ 전체 아키텍처

```
┌─────────────────────────────────────────────────────────┐
│                     사용자 인터페이스                      │
│                   (Streamlit Web UI)                    │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│                     API 서버 계층                         │
│                    (FastAPI REST API)                   │
│  ┌──────────┬──────────┬──────────┬──────────────────┐  │
│  │ 대본생성 │ 영상처리 │ 자막생성 │ 파일관리         │  │
│  │ Service  │ Service  │ Service  │ Service          │  │
│  └──────────┴──────────┴──────────┴──────────────────┘  │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│                  외부 API & 서비스                        │
│  ┌──────────┬──────────┬──────────┬──────────────────┐  │
│  │ OpenAI   │ ElevenLabs│ Douyin   │ Google Drive     │  │
│  │ GPT-4    │ TTS       │ Crawler  │ / AWS S3         │  │
│  └──────────┴──────────┴──────────┴──────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## 🏗️ 기술 스택 상세

### 1️⃣ 핵심 언어 & 프레임워크

#### Python 3.10+
**선택 이유:**
- AI/ML 생태계 최강 (TensorFlow, PyTorch, OpenAI 등)
- 비동기 처리 지원 (asyncio)
- 크로스 플랫폼 (Windows/Mac/Linux)
- 풍부한 멀티미디어 라이브러리 (FFmpeg, MoviePy)
- 초보자부터 전문가까지 사용 가능

**버전 요구사항:**
```bash
# Python 3.10 이상 필수 (타입 힌팅 개선)
python --version  # 3.10.0 이상

# 3.11 권장 (성능 10-60% 향상)
```

---

#### FastAPI (API 서버)
**역할:** RESTful API 서버 구축

**선택 이유:**
- 🚀 **빠름**: Node.js, Go 수준의 고성능
- 📝 **자동 문서화**: Swagger UI 자동 생성
- 🔒 **타입 안전**: Pydantic으로 데이터 검증
- ⚡ **비동기**: async/await 네이티브 지원
- 🎯 **초보자 친화적**: Flask보다 직관적

**사용 사례:**
```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class ScriptRequest(BaseModel):
    product_name: str
    category: str = "일반"

@app.post("/api/v1/generate-script")
async def generate_script(request: ScriptRequest):
    # 대본 생성 로직
    script = await script_service.generate(request.product_name)
    return {"script": script, "status": "success"}

# 실행: uvicorn main:app --reload
# 문서: http://localhost:8000/docs
```

**장점:**
- OpenAPI (Swagger) 문서 자동 생성
- 요청/응답 자동 검증
- 비동기 처리로 병렬 작업 가능 (여러 API 동시 호출)

**대안 비교:**
| 프레임워크 | 성능 | 학습곡선 | 문서화 | 비동기 | 추천도 |
|-----------|------|---------|--------|--------|--------|
| **FastAPI** ✅ | ⭐⭐⭐⭐⭐ | 쉬움 | 자동 | ✅ | ⭐⭐⭐⭐⭐ |
| Flask | ⭐⭐⭐ | 매우 쉬움 | 수동 | 확장필요 | ⭐⭐⭐ |
| Django | ⭐⭐⭐ | 어려움 | 훌륭 | ✅ | ⭐⭐ |

**API 구조 예시:**
```
POST   /api/v1/generate-script      # 대본 생성
POST   /api/v1/translate-keyword    # 키워드 번역
POST   /api/v1/generate-voice       # 음성 합성
POST   /api/v1/process-video        # 영상 처리
GET    /api/v1/projects             # 프로젝트 목록
GET    /api/v1/projects/{id}        # 프로젝트 상세
DELETE /api/v1/projects/{id}        # 프로젝트 삭제
GET    /api/v1/health               # 헬스체크
```

---

#### Streamlit (UI 프레임워크)
**역할:** 웹 기반 사용자 인터페이스

**선택 이유:**
- 🎨 **빠른 프로토타이핑**: 코드 몇 줄로 UI 완성
- 🔄 **실시간 업데이트**: 코드 수정 즉시 반영
- 📊 **데이터 시각화**: 차트, 그래프 기본 제공
- 🆓 **무료**: 상업적 이용 가능
- 👨‍💻 **개발자 친화적**: HTML/CSS/JS 불필요

**사용 사례:**
```python
import streamlit as st

st.title("🎬 쇼핑 쇼츠 자동화")

product_name = st.text_input("상품명 입력")
if st.button("대본 생성"):
    with st.spinner("생성 중..."):
        # FastAPI 호출
        response = requests.post("http://localhost:8000/api/v1/generate-script", 
                                json={"product_name": product_name})
        st.success("완료!")
        st.text_area("대본", response.json()["script"])
```

**MVP vs 프로덕션:**
- **MVP (Phase 1)**: Streamlit 단독 사용
- **프로덕션 (Phase 3)**: Streamlit (UI) + FastAPI (백엔드) 분리

**대안 비교:**
| UI 도구 | 개발속도 | 커스터마이징 | 성능 | 추천 Phase |
|---------|---------|-------------|------|------------|
| **Streamlit** ✅ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | Phase 1-2 |
| Gradio | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | 데모용 |
| React + FastAPI | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Phase 4 |
| Flask + Jinja2 | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | 중급자 |

---

#### 패키지 관리: Poetry vs pip

**Poetry (권장)**
**장점:**
- 의존성 해결 자동화
- 가상환경 자동 생성
- `pyproject.toml` 표준 사용
- 패키지 배포 간편

**설치 및 사용:**
```bash
# Poetry 설치
curl -sSL https://install.python-poetry.org | python3 -

# 프로젝트 초기화
poetry init

# 패키지 추가
poetry add fastapi streamlit openai

# 가상환경 활성화
poetry shell

# 실행
poetry run python main.py
```

**pip (대안)**
**장점:**
- Python 기본 도구
- 간단함

**사용:**
```bash
# 가상환경 생성
python -m venv venv
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# 패키지 설치
pip install -r requirements.txt
```

**선택 가이드:**
- **초보자**: pip (간단)
- **팀 프로젝트**: Poetry (의존성 관리 강력)

---

#### Docker (배포 환경)
**역할:** 컨테이너화를 통한 일관된 실행 환경 제공

**선택 이유:**
- 🐳 **환경 일관성**: "내 컴퓨터에선 되는데?" 문제 해결
- 📦 **쉬운 배포**: 이미지 하나로 어디서든 실행
- 🔄 **재현 가능**: 개발/스테이징/프로덕션 환경 동일
- ⚙️ **의존성 격리**: 시스템 환경 오염 방지

**Dockerfile 예시:**
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# FFmpeg 설치 (영상 처리용)
RUN apt-get update && apt-get install -y ffmpeg

# Poetry 설치
RUN pip install poetry

# 의존성 설치
COPY pyproject.toml poetry.lock ./
RUN poetry install --no-dev

# 애플리케이션 코드 복사
COPY . .

# 포트 노출
EXPOSE 8000

# 실행
CMD ["poetry", "run", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

**docker-compose.yml 예시:**
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    volumes:
      - ./project_output:/app/project_output
  
  ui:
    build: ./ui
    ports:
      - "8501:8501"
    depends_on:
      - api
```

**사용 시점:**
- **Phase 1-2**: 선택사항 (로컬 개발 충분)
- **Phase 3-4**: 권장 (배포 및 팀 협업)

---

### 2️⃣ AI 및 외부 API

#### OpenAI API (GPT-4/GPT-4o/GPT-5)

**사용 목적:**
- 📝 **대본 생성**: 30-45초 릴스 대본 자동 작성
- 🏷️ **썸네일 문구**: 6-8자 임팩트 문구 생성
- 📄 **설명란 작성**: CTA 포함 완성형 설명
- 🌏 **키워드 번역**: 한국어 → 중국어 (Douyin 검색용)
- 🎨 **콘텐츠 최적화**: A/B 테스트용 변형 생성

**모델 선택 가이드:**
| 모델 | 용도 | 속도 | 비용 | 품질 | 추천 |
|------|------|------|------|------|------|
| **GPT-4-turbo** | 대본 생성 | 빠름 | $10/1M in | ⭐⭐⭐⭐⭐ | ✅ MVP |
| GPT-4o | 멀티모달 | 매우 빠름 | $2.5/1M in | ⭐⭐⭐⭐ | ✅ Phase 2 |
| GPT-3.5-turbo | 번역/간단 작업 | 초고속 | $0.5/1M in | ⭐⭐⭐ | 비용 절감용 |
| o1-preview | 복잡한 추론 | 느림 | $15/1M in | ⭐⭐⭐⭐⭐ | 불필요 |

**비용 계산 (월 100개 콘텐츠 기준):**
```python
# 대본 1개당 토큰 사용량 예상
input_tokens = 500   # 프롬프트 + 제품정보
output_tokens = 1000 # 대본 + 썸네일 + 설명

# GPT-4-turbo 비용
cost_per_request = (500 * 0.01 + 1000 * 0.03) / 1000  # $0.035
monthly_cost = cost_per_request * 100 * 1300  # 약 ₩4,550

# GPT-3.5-turbo로 번역 (비용 절감)
translation_cost = 0.001 * 100 * 1300  # 약 ₩130

# 총 월 비용: 약 ₩5,000
```

**API 사용 예시:**
```python
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_script(product_name: str) -> dict:
    response = client.chat.completions.create(
        model="gpt-4-turbo-preview",
        messages=[
            {"role": "system", "content": "당신은 쇼핑 쇼츠 전문 크리에이터입니다."},
            {"role": "user", "content": f"상품: {product_name}\n\n30-45초 릴스 대본을 작성해주세요."}
        ],
        temperature=0.7,
        max_tokens=1500
    )
    
    return {
        "script": response.choices[0].message.content,
        "tokens": response.usage.total_tokens,
        "cost": response.usage.total_tokens * 0.00001  # 대략적 계산
    }
```

**프롬프트 엔지니어링 팁:**
```python
# 구조화된 출력을 위한 프롬프트
SCRIPT_PROMPT = """
다음 형식으로 출력해주세요:

### 대본
[30-45초 분량의 대본]

### 썸네일
[6-8자 임팩트 문구]

### 설명란
[해시태그 포함 설명 + CTA]

상품: {product_name}
카테고리: {category}
타겟: 20-40대 여성
"""
```

**에러 핸들링:**
```python
import openai
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def api_call_with_retry(prompt):
    try:
        return client.chat.completions.create(...)
    except openai.RateLimitError:
        logger.warning("Rate limit hit, retrying...")
        raise
    except openai.APIError as e:
        logger.error(f"API error: {e}")
        raise
```

---

#### 음성 합성 (TTS): ElevenLabs vs Google Cloud TTS

**서비스 비교:**

| 서비스 | 음성 품질 | 한국어 | 감정 표현 | 가격 | API 난이도 | 추천 |
|--------|----------|--------|----------|------|-----------|------|
| **ElevenLabs** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | $22/월 | 쉬움 | ⭐⭐⭐⭐⭐ |
| **Google Cloud TTS** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | $4/1M chars | 쉬움 | ⭐⭐⭐⭐ |
| OpenAI TTS | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | $15/1M chars | 매우 쉬움 | ⭐⭐⭐⭐ |
| Azure TTS | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | $4/1M chars | 보통 | ⭐⭐⭐ |

**ElevenLabs (1순위 추천)**

**장점:**
- 🎭 감정 표현 탁월 (놀람, 기쁨, 설득 등)
- 🎵 자연스러운 억양
- 🔊 목소리 클로닝 가능 (나만의 AI 보이스)
- 🌍 다국어 지원 (한국어 포함)

**사용 예시:**
```python
from elevenlabs import generate, set_api_key, voices

set_api_key(os.getenv("ELEVENLABS_API_KEY"))

def generate_voice(text: str, voice_id: str = "21m00Tcm4TlvDq8ikWAM") -> bytes:
    """
    Args:
        text: 변환할 텍스트
        voice_id: 목소리 ID (기본값: Rachel)
    
    Returns:
        MP3 오디오 바이트
    """
    audio = generate(
        text=text,
        voice=voice_id,
        model="eleven_multilingual_v2"  # 한국어 지원
    )
    
    return audio

# 파일 저장
with open("output.mp3", "wb") as f:
    f.write(generate_voice("장마철 신발 냄새 때문에 고민이신가요?"))
```

**가격:**
- **Free**: 10,000 chars/month (약 대본 20개)
- **Starter**: $5/month - 30,000 chars
- **Creator**: $22/month - 100,000 chars (월 200개 대본)
- **Pro**: $99/month - 500,000 chars

**Google Cloud TTS (가성비 옵션)**

**장점:**
- 💰 매우 저렴 ($4 per 1M characters)
- 🇰🇷 한국어 품질 우수 (WaveNet)
- 🔧 안정적인 서비스
- 📊 Google Cloud 생태계 통합

**사용 예시:**
```python
from google.cloud import texttospeech

client = texttospeech.TextToSpeechClient()

def google_tts(text: str, speed: float = 1.2) -> bytes:
    synthesis_input = texttospeech.SynthesisInput(text=text)
    
    voice = texttospeech.VoiceSelectionParams(
        language_code="ko-KR",
        name="ko-KR-Wavenet-A",  # 여성 목소리
        ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
    )
    
    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3,
        speaking_rate=speed  # 1.2배속
    )
    
    response = client.synthesize_speech(
        input=synthesis_input,
        voice=voice,
        audio_config=audio_config
    )
    
    return response.audio_content
```

**비용 비교 (월 100개 콘텐츠):**
```
대본 1개 평균: 200자

ElevenLabs Creator: $22/월 (고정) = ₩28,600
Google Cloud TTS: 200자 × 100개 = 20,000자 = $0.08 = ₩104

→ Google TTS가 압도적으로 저렴
→ 하지만 품질은 ElevenLabs가 우수
```

**추천 전략:**
- **Phase 1-2**: Google Cloud TTS (가성비)
- **Phase 3**: ElevenLabs (고품질, 브랜드 목소리)

---

#### 음성 인식 (STT): Whisper API

**사용 목적:**
- 🎤 다운로드한 Douyin 영상의 음성 추출
- 📝 자동 자막 생성 (SRT 파일)
- 🌏 다국어 자막 변환

**Whisper API vs 로컬 Whisper:**

| 항목 | Whisper API | 로컬 Whisper |
|------|------------|-------------|
| 속도 | ⚡ 빠름 (클라우드) | 🐢 느림 (GPU 필요) |
| 비용 | $0.006/분 | 무료 (전기세) |
| 품질 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ (동일) |
| 설정 | 간단 | 복잡 (CUDA 등) |
| 추천 | ✅ Phase 1-3 | Phase 4 (대용량) |

**Whisper API 사용 예시:**
```python
from openai import OpenAI

client = OpenAI()

def transcribe_audio(audio_path: str, language: str = "ko") -> dict:
    """
    음성 파일을 텍스트로 변환하고 SRT 생성
    
    Args:
        audio_path: 오디오 파일 경로
        language: 언어 코드 (ko, zh, en)
    
    Returns:
        {
            "text": "전체 텍스트",
            "srt": "SRT 형식 자막"
        }
    """
    with open(audio_path, "rb") as audio_file:
        # 자막 파일 생성 (SRT 형식)
        transcript = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_file,
            response_format="srt",  # srt, vtt, json
            language=language
        )
    
    return {
        "text": transcript.text,
        "srt": transcript.text  # SRT 형식
    }

# SRT 파일 저장
srt_content = transcribe_audio("douyin_video.mp4")
with open("subtitle.srt", "w", encoding="utf-8") as f:
    f.write(srt_content["srt"])
```

**비용 계산:**
```python
# 30초 영상
video_length_minutes = 0.5
cost = 0.006 * video_length_minutes  # $0.003 (약 ₩4)

# 월 100개 영상
monthly_cost = 0.003 * 100 * 1300  # 약 ₩400
```

**SRT 형식 예시:**
```srt
1
00:00:00,000 --> 00:00:03,500
장마철 신발 냄새 때문에 고민이신가요?

2
00:00:03,500 --> 00:00:07,000
이 무선 신발 건조기 하나면 해결됩니다.

3
00:00:07,000 --> 00:00:10,500
USB 충전식이라 어디서든 사용 가능하고
```

---

#### 썸네일/이미지 생성: OpenAI DALL·E 3

**사용 목적:**
- 🎨 커스텀 썸네일 이미지 생성
- 🖼️ 제품 없이 컨셉 이미지 제작
- 🔄 A/B 테스트용 여러 버전 생성

**DALL·E 3 장점:**
- GPT-4와 통합 (프롬프트 자동 개선)
- 텍스트 렌더링 가능 (이미지 내 글자)
- 고해상도 (1024x1024, 1024x1792)

**사용 예시:**
```python
from openai import OpenAI

client = OpenAI()

def generate_thumbnail(product_name: str, style: str = "realistic") -> str:
    """
    썸네일 이미지 생성
    
    Args:
        product_name: 상품명
        style: 스타일 (realistic, minimalist, vibrant)
    
    Returns:
        이미지 URL
    """
    prompt = f"""
    Create a vertical thumbnail (9:16) for a shopping short video about {product_name}.
    Style: {style}, modern, eye-catching
    Include: product in use, happy person, bright colors
    Text overlay: None (will be added in video editing)
    """
    
    response = client.images.generate(
        model="dall-e-3",
        prompt=prompt,
        size="1024x1792",  # 세로형 (9:16 비율)
        quality="standard",  # or "hd"
        n=1
    )
    
    return response.data[0].url

# 이미지 다운로드 및 저장
import requests
image_url = generate_thumbnail("무선 신발 건조기")
img_data = requests.get(image_url).content
with open("thumbnail.png", "wb") as f:
    f.write(img_data)
```

**가격:**
```
Standard (1024x1024): $0.040/image
Standard (1024x1792): $0.080/image
HD (1024x1024): $0.080/image
HD (1024x1792): $0.120/image

월 100개 썸네일 (Standard 세로형): $8 = ₩10,400
```

**대안: 무료 옵션**
- **Stable Diffusion** (로컬): 무료, GPU 필요
- **Midjourney** (유료): $10/월, Discord 사용
- **Canva** (수동): 무료, 템플릿 활용

**추천:**
- **Phase 1-2**: 수동 (Canva, 제품 이미지 직접 사용)
- **Phase 3**: DALL·E 3 (자동화, 대량 생성)

---

### 3️⃣ 영상 수집 및 처리

#### 영상 다운로드: yt-dlp + Selenium

**yt-dlp**
**역할:** YouTube, Douyin, TikTok 등 800+ 사이트 영상 다운로드

**장점:**
- 🌐 거의 모든 플랫폼 지원
- 📺 고화질 다운로드 (4K, 8K)
- 🎵 오디오 분리 추출 가능
- 🆓 오픈소스, 무료

**설치 및 사용:**
```bash
# 설치
pip install yt-dlp

# Douyin 영상 다운로드 (Python)
```

```python
import yt_dlp

def download_douyin_video(url: str, output_path: str = "downloads") -> str:
    """
    Douyin 영상 다운로드
    
    Args:
        url: Douyin 영상 URL
        output_path: 저장 경로
    
    Returns:
        다운로드된 파일 경로
    """
    ydl_opts = {
        'format': 'best',  # 최고 화질
        'outtmpl': f'{output_path}/%(title)s.%(ext)s',
        'quiet': False,
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
    
    return filename

# 사용
video_path = download_douyin_video("https://v.douyin.com/xxxxx")
```

**Selenium (동적 크롤링)**
**역할:** Douyin 검색 → 영상 목록 수집 → URL 추출

**사용 사례:**
```python
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def search_douyin_videos(keyword: str, max_results: int = 5) -> list:
    """
    Douyin에서 키워드로 영상 검색
    
    Args:
        keyword: 검색 키워드 (중국어)
        max_results: 수집할 영상 개수
    
    Returns:
        영상 URL 리스트
    """
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')  # 백그라운드 실행
    driver = webdriver.Chrome(options=options)
    
    # Douyin 검색
    search_url = f"https://www.douyin.com/search/{keyword}"
    driver.get(search_url)
    time.sleep(3)  # 페이지 로딩 대기
    
    # 영상 링크 추출
    video_elements = driver.find_elements(By.CSS_SELECTOR, "a[href*='/video/']")
    video_urls = [elem.get_attribute('href') for elem in video_elements[:max_results]]
    
    driver.quit()
    return video_urls

# 사용
urls = search_douyin_videos("无线鞋子烘干机", max_results=3)
for url in urls:
    download_douyin_video(url)
```

**주의사항:**
- ⚠️ VPN 필요 (중국 플랫폼 접근)
- ⚠️ User-Agent 설정 (봇 감지 회피)
- ⚠️ Rate limiting (과도한 요청 금지)

---

#### 영상 편집: MoviePy + FFmpeg

**FFmpeg**
**역할:** 멀티미디어 처리의 스위스 아미 나이프

**주요 기능:**
- 🎬 영상 변환, 인코딩
- ✂️ 자르기, 합치기
- 📐 리사이즈 (16:9 → 9:16)
- 🎵 오디오 합성
- 📝 자막 오버레이

**설치:**
```bash
# Mac
brew install ffmpeg

# Ubuntu
sudo apt update
sudo apt install ffmpeg

# Windows
# https://ffmpeg.org/download.html에서 다운로드
```

**기본 명령어:**
```bash
# 16:9 → 9:16 변환 (중앙 크롭)
ffmpeg -i input.mp4 -vf "crop=ih*(9/16):ih" -c:a copy output.mp4

# 리사이즈 + 패딩
ffmpeg -i input.mp4 -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" output.mp4

# 자막 합성
ffmpeg -i video.mp4 -vf subtitles=subtitle.srt output.mp4

# 여러 영상 합치기
ffmpeg -f concat -safe 0 -i filelist.txt -c copy output.mp4
```

**MoviePy (Python 래퍼)**
**역할:** Python으로 FFmpeg 제어

**사용 예시:**
```python
from moviepy.editor import *

def create_shorts_video(
    video_paths: list,
    audio_path: str,
    subtitle_path: str,
    output_path: str
):
    """
    쇼츠 영상 생성
    
    Args:
        video_paths: 소스 영상 경로 리스트
        audio_path: AI 음성 파일 경로
        subtitle_path: SRT 자막 파일 경로
        output_path: 출력 경로
    """
    # 1. 영상 불러오기 및 합치기
    clips = [VideoFileClip(path) for path in video_paths]
    video = concatenate_videoclips(clips, method="compose")
    
    # 2. 9:16 비율로 리사이즈 (중앙 크롭)
    video = video.crop(
        x_center=video.w/2,
        y_center=video.h/2,
        width=video.h * 9/16,
        height=video.h
    ).resize((1080, 1920))
    
    # 3. AI 음성 추가
    audio = AudioFileClip(audio_path)
    video = video.set_audio(audio)
    
    # 4. 자막 추가
    video = video.subclip(0, audio.duration)  # 음성 길이에 맞춤
    
    # 5. 내보내기
    video.write_videofile(
        output_path,
        fps=30,
        codec='libx264',
        audio_codec='aac',
        threads=4,
        preset='medium'
    )
    
    # 메모리 정리
    video.close()
    audio.close()

# 사용
create_shorts_video(
    video_paths=["clip1.mp4", "clip2.mp4"],
    audio_path="voice.mp3",
    subtitle_path="subtitle.srt",
    output_path="final_shorts.mp4"
)
```

**최적화 팁:**
```python
# 병렬 처리로 속도 향상
from concurrent.futures import ThreadPoolExecutor

def batch_process_videos(video_list: list):
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(create_shorts_video, video_data)
            for video_data in video_list
        ]
        results = [f.result() for f in futures]
    return results
```

---

#### 자막 처리: FFmpeg filter_complex

**자막 스타일링**

**기본 SRT → 스타일링된 자막:**
```python
def style_subtitles(srt_path: str, output_path: str):
    """
    SRT 자막을 FFmpeg로 스타일링
    """
    ffmpeg_cmd = f"""
    ffmpeg -i video.mp4 -vf "subtitles={srt_path}:force_style='
        FontName=NanumGothicBold,
        FontSize=24,
        PrimaryColour=&H00FFFFFF,
        OutlineColour=&H00000000,
        BorderStyle=3,
        Outline=2,
        Shadow=0,
        Alignment=2,
        MarginV=50
    '" {output_path}
    """
    os.system(ffmpeg_cmd)
```

**실시간 자막 생성 (Whisper + FFmpeg):**
```python
def auto_subtitle_video(video_path: str, output_path: str, language: str = "ko"):
    """
    영상에 자동 자막 추가
    
    1. Whisper로 음성 인식 → SRT 생성
    2. FFmpeg로 자막 오버레이
    """
    # 1. 음성 추출
    audio_path = "temp_audio.mp3"
    os.system(f"ffmpeg -i {video_path} -q:a 0 -map a {audio_path}")
    
    # 2. Whisper로 자막 생성
    client = OpenAI()
    with open(audio_path, "rb") as audio:
        srt_content = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio,
            response_format="srt",
            language=language
        )
    
    # 3. SRT 파일 저장
    srt_path = "subtitle.srt"
    with open(srt_path, "w", encoding="utf-8") as f:
        f.write(srt_content.text)
    
    # 4. 자막 합성
    style_subtitles(srt_path, output_path)
    
    # 정리
    os.remove(audio_path)
    os.remove(srt_path)
```

---

#### CapCut JSON 파싱 (고급 기능)

**역할:** CapCut Desktop 프로젝트 파일을 분석하여 편집 정보 추출

**사용 사례:**
- 수동으로 만든 CapCut 템플릿을 자동화에 활용
- 편집 패턴 학습 및 재현

**CapCut 프로젝트 구조:**
```json
{
  "materials": {
    "videos": [...],
    "audios": [...],
    "texts": [...]
  },
  "tracks": [
    {
      "type": "video",
      "segments": [...]
    }
  ]
}
```

**파싱 예시:**
```python
import json

def parse_capcut_project(project_path: str) -> dict:
    """
    CapCut 프로젝트 파일 파싱
    
    Returns:
        {
            "duration": 전체 길이,
            "texts": 텍스트 레이어 정보,
            "transitions": 전환 효과 정보
        }
    """
    with open(project_path, "r", encoding="utf-8") as f:
        project = json.load(f)
    
    return {
        "duration": project["duration"],
        "texts": [
            {
                "content": text["content"],
                "start": text["start"],
                "end": text["end"],
                "style": text["style"]
            }
            for text in project["materials"]["texts"]
        ],
        "transitions": project.get("transitions", [])
    }

# 사용: 템플릿에서 텍스트 위치 정보 추출
template_info = parse_capcut_project("template.draf")
# → 이 정보를 FFmpeg 명령어로 변환하여 자동 편집
```

**한계:**
- CapCut의 모든 효과를 FFmpeg로 재현 불가
- 기본 편집(자르기, 합치기, 자막)만 자동화 권장
- 고급 효과는 수동 유지

---

### 4️⃣ 데이터베이스 및 파일 관리

#### 프로젝트 데이터 저장: SQLite vs Google Sheets

**SQLite (로컬 DB)**
**장점:**
- 📦 단일 파일 DB (이식성 좋음)
- 🚀 빠름 (로컬 접근)
- 🆓 무료, 설정 불필요
- 🔧 Python 기본 포함

**사용 예시:**
```python
import sqlite3
from datetime import datetime

class ProjectDatabase:
    def __init__(self, db_path: str = "projects.db"):
        self.conn = sqlite3.connect(db_path)
        self.create_tables()
    
    def create_tables(self):
        """테이블 생성"""
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_name TEXT NOT NULL,
                category TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                script TEXT,
                thumbnail_text TEXT,
                douyin_keywords TEXT,
                video_path TEXT,
                status TEXT DEFAULT 'draft',
                views INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                revenue REAL DEFAULT 0.0
            )
        """)
        self.conn.commit()
    
    def add_project(self, product_name: str, script_data: dict) -> int:
        """프로젝트 추가"""
        cursor = self.conn.execute("""
            INSERT INTO projects (product_name, script, thumbnail_text, douyin_keywords)
            VALUES (?, ?, ?, ?)
        """, (
            product_name,
            script_data['script'],
            script_data['thumbnail'],
            script_data.get('douyin_keywords', '')
        ))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_all_projects(self) -> list:
        """모든 프로젝트 조회"""
        cursor = self.conn.execute("""
            SELECT id, product_name, status, created_at, revenue
            FROM projects
            ORDER BY created_at DESC
        """)
        return cursor.fetchall()
    
    def update_metrics(self, project_id: int, views: int, clicks: int, revenue: float):
        """성과 지표 업데이트"""
        self.conn.execute("""
            UPDATE projects
            SET views = ?, clicks = ?, revenue = ?
            WHERE id = ?
        """, (views, clicks, revenue, project_id))
        self.conn.commit()

# 사용
db = ProjectDatabase()
project_id = db.add_project("무선 신발 건조기", script_data)
```

**Google Sheets API (클라우드 연동)**
**장점:**
- ☁️ 클라우드 기반 (어디서든 접근)
- 👥 팀 협업 쉬움
- 📊 실시간 대시보드
- 📱 모바일 앱 연동

**사용 예시:**
```python
import gspread
from oauth2client.service_account import ServiceAccountCredentials

class SheetsDatabase:
    def __init__(self, sheet_name: str = "쇼핑쇼츠_프로젝트"):
        scope = ['https://spreadsheets.google.com/feeds',
                 'https://www.googleapis.com/auth/drive']
        
        creds = ServiceAccountCredentials.from_json_keyfile_name(
            'credentials.json', scope
        )
        client = gspread.authorize(creds)
        self.sheet = client.open(sheet_name).sheet1
    
    def add_project(self, data: dict):
        """새 프로젝트 추가"""
        row = [
            datetime.now().isoformat(),
            data['product_name'],
            data['script'],
            data['thumbnail'],
            data.get('status', 'draft'),
            0,  # views
            0,  # clicks
            0.0  # revenue
        ]
        self.sheet.append_row(row)
    
    def get_all_projects(self) -> list:
        """모든 프로젝트 조회"""
        return self.sheet.get_all_records()

# 사용
sheets_db = SheetsDatabase()
sheets_db.add_project({
    'product_name': '무선 신발 건조기',
    'script': '...',
    'thumbnail': '신발 냄새 제거'
})
```

**선택 가이드:**
| 기준 | SQLite | Google Sheets |
|------|--------|---------------|
| 속도 | ⚡ 매우 빠름 | 🐢 느림 (API 호출) |
| 협업 | ❌ 어려움 | ✅ 쉬움 |
| 비용 | 무료 | 무료 (한도 있음) |
| 확장성 | 제한적 | 무제한 |
| 추천 | Phase 1-2 | Phase 3-4 |

---

#### 파일 관리: pathlib + os

**pathlib (현대적 방식, 권장)**
```python
from pathlib import Path
import shutil

class FileManager:
    def __init__(self, base_dir: str = "project_output"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(exist_ok=True)
    
    def create_project_folder(self, product_name: str) -> Path:
        """프로젝트 폴더 생성"""
        # 파일명 안전화
        safe_name = self._sanitize_filename(product_name)
        
        # 날짜 추가
        date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder_name = f"{safe_name}_{date_str}"
        
        folder_path = self.base_dir / folder_name
        folder_path.mkdir(parents=True, exist_ok=True)
        
        # 하위 폴더 생성
        (folder_path / "scripts").mkdir(exist_ok=True)
        (folder_path / "videos").mkdir(exist_ok=True)
        (folder_path / "audio").mkdir(exist_ok=True)
        (folder_path / "subtitles").mkdir(exist_ok=True)
        
        return folder_path
    
    def save_text_file(self, folder: Path, filename: str, content: str):
        """텍스트 파일 저장"""
        file_path = folder / filename
        file_path.write_text(content, encoding="utf-8")
    
    def save_json(self, folder: Path, filename: str, data: dict):
        """JSON 파일 저장"""
        file_path = folder / filename
        file_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), 
                            encoding="utf-8")
    
    def move_file(self, src: Path, dst: Path):
        """파일 이동"""
        shutil.move(str(src), str(dst))
    
    def _sanitize_filename(self, filename: str) -> str:
        """파일명 안전화 (특수문자 제거)"""
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        return filename[:50]  # 길이 제한

# 사용
fm = FileManager()
project_folder = fm.create_project_folder("무선 신발 건조기")
fm.save_text_file(project_folder, "script.txt", script_content)
fm.save_json(project_folder / "scripts", "metadata.json", metadata)
```

---

#### 클라우드 스토리지: Google Drive / AWS S3

**Google Drive API**
**사용 사례:**
- 완성된 영상 자동 업로드
- 팀원과 공유
- 모바일 접근

```python
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

class GoogleDriveUploader:
    def __init__(self, credentials_path: str):
        self.service = build('drive', 'v3', credentials=credentials_path)
    
    def upload_video(self, file_path: str, folder_id: str = None) -> str:
        """영상을 Google Drive에 업로드"""
        file_metadata = {
            'name': Path(file_path).name,
            'mimeType': 'video/mp4'
        }
        
        if folder_id:
            file_metadata['parents'] = [folder_id]
        
        media = MediaFileUpload(file_path, mimetype='video/mp4')
        
        file = self.service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, webViewLink'
        ).execute()
        
        return file.get('webViewLink')

# 사용
uploader = GoogleDriveUploader("credentials.json")
link = uploader.upload_video("final_shorts.mp4", folder_id="xxxxx")
print(f"업로드 완료: {link}")
```

**AWS S3 (대용량, 프로덕션)**
```python
import boto3

class S3Uploader:
    def __init__(self, bucket_name: str):
        self.s3 = boto3.client('s3')
        self.bucket = bucket_name
    
    def upload_file(self, file_path: str, s3_key: str) -> str:
        """S3에 파일 업로드"""
        self.s3.upload_file(file_path, self.bucket, s3_key)
        
        # Public URL 생성
        url = f"https://{self.bucket}.s3.amazonaws.com/{s3_key}"
        return url

# 사용
s3 = S3Uploader("my-shorts-bucket")
url = s3.upload_file("final_shorts.mp4", "videos/2025/01/shorts_001.mp4")
```

**비용 비교 (월 100개 영상, 각 50MB):**
```
총 용량: 5GB/월

Google Drive: 무료 (15GB 한도)
AWS S3:
  - 스토리지: $0.023/GB = $0.115/월
  - 전송: $0.09/GB × 5GB = $0.45/월
  - 총: 약 ₩650/월
```

---

#### 환경 설정: .env + YAML

**.env 파일 (민감 정보)**
```bash
# API Keys
OPENAI_API_KEY=sk-proj-xxxxx
ELEVENLABS_API_KEY=xxxxx
GOOGLE_SHEETS_CREDENTIALS=./credentials.json

# Database
DATABASE_URL=sqlite:///projects.db

# Storage
AWS_ACCESS_KEY_ID=xxxxx
AWS_SECRET_ACCESS_KEY=xxxxx
AWS_BUCKET_NAME=my-shorts-bucket

# App Settings
DEBUG=true
MAX_DAILY_REQUESTS=100
```

**config.yaml (일반 설정)**
```yaml
app:
  name: "쇼핑 쇼츠 자동화"
  version: "1.0.0"
  
paths:
  output_dir: "project_output"
  temp_dir: "temp"
  
video:
  resolution:
    width: 1080
    height: 1920
  fps: 30
  codec: "libx264"
  
script:
  min_length: 30
  max_length: 45
  temperature: 0.7
  
tts:
  provider: "elevenlabs"  # or "google"
  speed: 1.2
  voice_id: "21m00Tcm4TlvDq8ikWAM"
```

**설정 로드:**
```python
import os
from dotenv import load_dotenv
import yaml

class Config:
    def __init__(self):
        # .env 로드
        load_dotenv()
        
        # YAML 로드
        with open("config.yaml", "r") as f:
            self.config = yaml.safe_load(f)
        
        # API 키
        self.openai_key = os.getenv("OPENAI_API_KEY")
        self.elevenlabs_key = os.getenv("ELEVENLABS_API_KEY")
        
        # 경로 설정
        self.output_dir = self.config['paths']['output_dir']
        
        # 영상 설정
        self.video_config = self.config['video']
    
    def validate(self):
        """필수 설정 검증"""
        if not self.openai_key:
            raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다!")

# 사용
config = Config()
config.validate()
```

---

## 📊 전체 의존성 패키지

### requirements.txt (Phase 1-2)
```txt
# 웹 프레임워크
fastapi==0.109.0
uvicorn[standard]==0.27.0
streamlit==1.31.0

# AI/LLM
openai==1.12.0

# 데이터 처리
pandas==2.2.0
sqlalchemy==2.0.25

# 환경 변수
python-dotenv==1.0.0
pyyaml==6.0.1

# 영상 처리
moviepy==1.0.3
yt-dlp==2024.1.1

# 웹 크롤링
selenium==4.17.0
beautifulsoup4==4.12.3
requests==2.31.0

# TTS (선택)
elevenlabs==0.2.26
google-cloud-texttospeech==2.16.0

# 클라우드 (선택)
google-api-python-client==2.115.0
gspread==5.12.3
boto3==1.34.34

# 유틸리티
tenacity==8.2.3  # 재시도 로직
pillow==10.2.0   # 이미지 처리
```

### pyproject.toml (Poetry)
```toml
[tool.poetry]
name = "shopping-shorts-automation"
version = "1.0.0"
description = "쇼핑 쇼츠 자동화 시스템"
authors = ["Your Name <your.email@example.com>"]

[tool.poetry.dependencies]
python = "^3.10"
fastapi = "^0.109.0"
streamlit = "^1.31.0"
openai = "^1.12.0"
pandas = "^2.2.0"
moviepy = "^1.0.3"
yt-dlp = "^2024.1.1"

[tool.poetry.dev-dependencies]
pytest = "^7.4.4"
black = "^24.1.1"
flake8 = "^7.0.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

---

## 🐳 Docker 설정

### Dockerfile
```dockerfile
FROM python:3.11-slim

# 작업 디렉토리
WORKDIR /app

# 시스템 패키지 설치 (FFmpeg 등)
RUN apt-get update && apt-get install -y \
    ffmpeg \
    wget \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Poetry 설치
RUN pip install poetry

# 의존성 파일 복사
COPY pyproject.toml poetry.lock ./

# 의존성 설치 (가상환경 비활성화)
RUN poetry config virtualenvs.create false \
    && poetry install --no-dev --no-interaction --no-ansi

# 애플리케이션 코드 복사
COPY . .

# 포트 노출
EXPOSE 8000 8501

# 헬스체크
HEALTHCHECK --interval=30s --timeout=3s \
    CMD curl -f http://localhost:8000/health || exit 1

# 실행 스크립트
CMD ["sh", "-c", "uvicorn app.main:app --host 0.0.0.0 --port 8000 & streamlit run app/ui.py --server.port 8501"]
```

### docker-compose.yml
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ELEVENLABS_API_KEY=${ELEVENLABS_API_KEY}
    volumes:
      - ./project_output:/app/project_output
      - ./temp:/app/temp
    restart: unless-stopped
  
  ui:
    build: ./ui
    ports:
      - "8501:8501"
    depends_on:
      - api
    environment:
      - API_URL=http://api:8000
    restart: unless-stopped

volumes:
  project_output:
  temp:
```

---

## 🚀 Phase별 기술 스택 로드맵

### Phase 1: MVP (2주)
**사용 기술:**
- Python + Streamlit
- OpenAI API (GPT-4)
- pathlib + SQLite
- .env

**목표:** 대본 생성 자동화

---

### Phase 2: 콘텐츠 제작 (2주)
**추가 기술:**
- Google Cloud TTS
- MoviePy + FFmpeg
- Whisper API

**목표:** 음성/자막/기본 편집 자동화

---

### Phase 3: 완전 자동화 (2주)
**추가 기술:**
- FastAPI (API 서버 분리)
- Selenium + yt-dlp
- Docker
- Google Drive API

**목표:** 영상 수집부터 저장까지 완전 자동화

---

### Phase 4: 프로덕션 (선택)
**추가 기술:**
- AWS S3
- React (UI 개선)
- ElevenLabs (고품질 TTS)
- PostgreSQL (SQLite 대체)

**목표:** 상용 서비스 수준

---

## 💰 총 비용 예상 (월 100개 콘텐츠)

| 항목 | 서비스 | 월 비용 |
|------|--------|---------|
| 대본 생성 | OpenAI GPT-4 | ₩5,000 |
| 음성 합성 | Google TTS | ₩100 |
| 음성 인식 | Whisper API | ₩400 |
| 썸네일 생성 | DALL·E 3 (선택) | ₩10,000 |
| 스토리지 | AWS S3 (선택) | ₩650 |
| **합계 (기본)** | | **₩5,500** |
| **합계 (풀옵션)** | | **₩16,150** |

---

## 📝 변경 이력

| 날짜 | 버전 | 변경 내용 |
|------|------|----------|
| 2025-10-30 | v2.0 | PDF 문서와 통합, FastAPI/Docker/Whisper 등 추가 |
| 2025-10-30 | v1.0 | 초기 문서 작성 |

---

> 💡 **다음 단계**: 이 기술 스택을 기반으로 실제 코드 개발을 시작합니다!

```
shopping_shorts_automation/
│
├── 📁 app/
│   ├── main.py                      # Streamlit 메인 앱
│   └── config.py                    # 설정 관리 (API 키, 경로 등)
│
├── 📁 modules/
│   ├── __init__.py
│   ├── script_generator.py          # 대본 생성 (OpenAI API)
│   ├── keyword_translator.py        # 키워드 번역
│   ├── file_manager.py               # 파일/폴더 생성 및 관리
│   ├── coupang_parser.py             # 쿠팡 URL 파싱 (선택)
│   ├── checklist_creator.py          # 체크리스트 생성
│   └── utils.py                      # 유틸리티 함수
│
├── 📁 prompts/
│   ├── script_prompt.txt             # 대본 생성 프롬프트 템플릿
│   ├── translation_prompt.txt        # 번역 프롬프트
│   └── thumbnail_prompt.txt          # 썸네일 문구 프롬프트
│
├── 📁 templates/
│   └── checklist_template.csv        # 체크리스트 기본 템플릿
│
├── 📁 project_output/                # 생성된 프로젝트 폴더들
│   ├── 신발건조기_20251030/
│   │   ├── script.txt                # 대본
│   │   ├── thumbnail.txt             # 썸네일 문구
│   │   ├── description.txt           # 설명란 + CTA
│   │   ├── douyin_keywords.txt       # 중국어 키워드
│   │   ├── checklist.csv             # 작업 체크리스트
│   │   └── metadata.json             # 메타 정보
│   └── 미니선풍기_20251031/
│       └── ...
│
├── 📁 docs/                          # 문서
│   ├── TECH_STACK.md                 # 이 문서
│   ├── DEVELOPMENT_PLAN.md           # 개발 계획
│   └── USER_GUIDE.md                 # 사용자 가이드
│
├── 📁 tests/                         # 테스트 코드 (선택)
│   ├── test_script_generator.py
│   └── test_file_manager.py
│
├── .env                              # 환경 변수 (gitignore!)
├── .env.example                      # 환경 변수 예시
├── .gitignore                        # Git 제외 파일
├── requirements.txt                  # Python 패키지 목록
├── README.md                         # 프로젝트 소개
└── setup.py                          # 설치 스크립트 (선택)
```

---

### 8. 개발 환경 & 도구

#### 코드 에디터 추천

**1순위: Visual Studio Code**
- Python 확장 프로그램 풍부
- 무료
- Git 통합
- 터미널 내장

**필수 VS Code 확장:**
```
- Python (Microsoft)
- Pylance
- GitLens
- Python Docstring Generator
```

**2순위: PyCharm Community Edition**
- 초보자 친화적
- 자동완성 강력
- 디버깅 쉬움

**3순위: Cursor**
- AI 코딩 어시스턴트 내장
- VS Code 기반
- 유료 ($20/월)

#### 가상 환경 설정

**방법 1: venv (Python 기본)**
```bash
# 가상환경 생성
python -m venv venv

# 활성화 (Mac/Linux)
source venv/bin/activate

# 활성화 (Windows)
venv\Scripts\activate

# 패키지 설치
pip install -r requirements.txt

# 비활성화
deactivate
```

**방법 2: conda**
```bash
# 가상환경 생성
conda create -n shorts_auto python=3.10

# 활성화
conda activate shorts_auto

# 패키지 설치
pip install -r requirements.txt
```

**권장:** venv (별도 설치 필요 없음)

#### 버전 관리

**Git 설정:**
```bash
git init
git add .
git commit -m "Initial commit"
```

**.gitignore 필수 내용:**
```
# 환경 변수
.env

# 가상환경
venv/
env/

# 출력 폴더
project_output/

# Python 캐시
__pycache__/
*.pyc
*.pyo

# IDE
.vscode/
.idea/

# 로그
*.log
```

---

### 9. 보안 & 모범 사례

#### ✅ 해야 할 것

**1. API 키 보안**
```python
# ❌ 나쁜 예
api_key = "sk-proj-xxxxx"  # 하드코딩 절대 금지!

# ✅ 좋은 예
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    raise ValueError("API 키가 설정되지 않았습니다!")
```

**2. 에러 핸들링**
```python
import openai

try:
    response = openai.ChatCompletion.create(...)
except openai.error.RateLimitError:
    print("⚠️ API 요청 한도 초과!")
except openai.error.APIError as e:
    print(f"⚠️ API 오류: {e}")
except Exception as e:
    print(f"⚠️ 예상치 못한 오류: {e}")
```

**3. 로깅**
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
logger.info("대본 생성 시작")
```

**4. 비용 제한**
```python
# API 호출 횟수 제한
MAX_REQUESTS_PER_DAY = 100
request_count = 0

def generate_script(product_name):
    global request_count
    
    if request_count >= MAX_REQUESTS_PER_DAY:
        raise Exception("일일 요청 한도 초과!")
    
    # API 호출
    ...
    request_count += 1
```

#### ❌ 하지 말아야 할 것

- ❌ API 키를 GitHub에 업로드
- ❌ 무한 루프로 API 호출 (비용 폭탄)
- ❌ 개인정보를 로그 파일에 저장
- ❌ 에러 무시 (try-except만 쓰고 처리 안함)
- ❌ 전역 변수 남용

---

### 10. 비용 예상 (월 100개 콘텐츠 기준)

#### Phase 1 (대본 생성만)

| 항목 | 서비스 | 단가 | 월 사용량 | 월 비용 |
|------|--------|------|----------|---------|
| 대본 생성 | OpenAI GPT-4 | ₩50/건 | 100건 | ₩5,000 |
| 키워드 번역 | OpenAI GPT-4 | ₩10/건 | 100건 | ₩1,000 |
| 호스팅 | 로컬 실행 | - | - | ₩0 |
| **합계** | | | | **₩6,000** |

#### Phase 2 (음성 합성 추가)

| 항목 | 서비스 | 단가 | 월 사용량 | 월 비용 |
|------|--------|------|----------|---------|
| 대본 생성 | OpenAI GPT-4 | ₩50/건 | 100건 | ₩5,000 |
| 키워드 번역 | OpenAI GPT-4 | ₩10/건 | 100건 | ₩1,000 |
| 음성 합성 | Google TTS | ₩1/건 | 100건 | ₩100 |
| **합계** | | | | **₩6,100** |

#### Phase 3 (고품질 음성)

| 항목 | 서비스 | 단가 | 월 사용량 | 월 비용 |
|------|--------|------|----------|---------|
| 대본 생성 | OpenAI GPT-4 | ₩50/건 | 100건 | ₩5,000 |
| 키워드 번역 | OpenAI GPT-4 | ₩10/건 | 100건 | ₩1,000 |
| 음성 합성 | ElevenLabs | - | Professional | ₩29,000 |
| **합계** | | | | **₩35,000** |

**결론:** Phase 1-2는 매우 저렴, Phase 3는 선택적

---

### 11. 의존성 패키지 (requirements.txt)

```txt
# 웹 프레임워크
streamlit==1.31.0

# AI/LLM
openai==1.12.0

# 데이터 처리
pandas==2.2.0

# 환경 변수
python-dotenv==1.0.0

# 웹 크롤링 (선택)
requests==2.31.0
beautifulsoup4==4.12.3

# Phase 2 이후
# selenium==4.17.0  # 동적 크롤링
# moviepy==1.0.3     # 영상 편집
# google-cloud-texttospeech==2.16.0  # TTS
```

---

## 🤔 최종 결정 사항

### ✅ 확정된 기술

| 분야 | 선택 | 이유 |
|------|------|------|
| 언어 | Python 3.10+ | 초보자 친화적, 라이브러리 풍부 |
| UI | Streamlit | 간단, 빠른 개발 |
| AI | OpenAI GPT-4 | 안정성, 성능 |
| 데이터 | Pandas | 표준, 강력함 |
| 환경 변수 | python-dotenv | 간단, 안전 |

### 🔄 Phase별 추가 기술

**Phase 1 (현재):**
- ✅ Python + Streamlit
- ✅ OpenAI API
- ✅ Pandas

**Phase 2:**
- Google Cloud TTS
- MoviePy + FFmpeg
- (선택) BeautifulSoup4

**Phase 3:**
- Selenium
- ElevenLabs API
- 고급 영상 처리

### ⏸️ 보류/제외

| 기술 | 이유 | 재검토 시점 |
|------|------|-----------|
| 쿠팡 크롤링 | IP 차단 위험, 초보자 어려움 | Phase 2 |
| Selenium | 복잡도 높음 | Phase 3 |
| 자동 업로드 | 계정 제재 위험 | Phase 4 |
| 로컬 LLM | 성능 낮음 | 고려 안함 |

---

## 📅 다음 단계

1. ✅ 기술 스택 확정 (완료)
2. ⬜ 개발 환경 세팅
3. ⬜ 폴더 구조 생성
4. ⬜ 프롬프트 템플릿 작성
5. ⬜ 핵심 모듈 개발 시작

---

## 📝 변경 이력

| 날짜 | 버전 | 변경 내용 |
|------|------|----------|
| 2025-10-30 | v1.0 | 초기 문서 작성 |

---

> 💡 **참고**: 이 문서는 프로젝트 진행에 따라 지속적으로 업데이트됩니다.
> 기술적 이슈나 더 나은 대안이 발견되면 수정될 수 있습니다.
